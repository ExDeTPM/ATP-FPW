// Funções gerais do site
document.addEventListener('DOMContentLoaded', function() {
    // Adicionar funcionalidades gerais aqui, se necessário
});